"""Validate, deduplicate, and split Kev records by exact state."""
from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path


def state_key(state) -> str:
    return hashlib.sha256(json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def valid(record: dict) -> str | None:
    if not isinstance(record.get("state"), (str, dict, list)) or record["state"] in ("", {}, []):
        return "state is empty or not text/JSON"
    questions = record.get("questions")
    if not isinstance(questions, dict) or not questions:
        return "questions is empty"
    for qid, question in questions.items():
        kind, label = question.get("type"), question.get("label")
        if not question.get("instructions"):
            return f"{qid}: missing instructions"
        if kind == "noul" and not isinstance(label, bool):
            return f"{qid}: noul label is not boolean"
        if kind == "choice" and label not in (question.get("criteria") or {}):
            return f"{qid}: choice label is not a criterion"
        if kind == "score" and (isinstance(label, bool) or not isinstance(label, int) or not 0 <= label < len(question.get("criteria") or [])):
            return f"{qid}: score label is invalid"
        if kind not in {"noul", "choice", "score"}:
            return f"{qid}: unknown type"
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--calibration", type=float, default=.15)
    parser.add_argument("--development", type=float, default=.15)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    if not 0 < args.calibration + args.development < 1:
        parser.error("calibration + development must be between zero and one")
    groups, seen, invalid = defaultdict(list), set(), []
    for number, line in enumerate(args.input.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            invalid.append(f"line {number}: invalid JSON")
            continue
        problem = valid(record)
        if problem:
            invalid.append(f"line {number}: {problem}")
            continue
        fingerprint = json.dumps({"state": record["state"], "questions": record["questions"]}, sort_keys=True, ensure_ascii=False)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        groups[state_key(record["state"])].append(record)
    keys = list(groups)
    if len(keys) < 3:
        raise SystemExit("need at least three distinct states for train, calibration, and development")
    random.Random(args.seed).shuffle(keys)
    development = max(1, round(len(keys) * args.development))
    calibration = max(1, round(len(keys) * args.calibration))
    if development + calibration >= len(keys):
        calibration = 1
        development = 1
    partitions = {"development": keys[:development], "calibration": keys[development:development + calibration], "train": keys[development + calibration:]}
    if any(not part for part in partitions.values()):
        raise SystemExit("one partition is empty; add more labelled samples")
    args.out.mkdir(parents=True, exist_ok=False)
    summary = {"input": str(args.input), "invalid": invalid, "partitions": {}}
    for name, state_ids in partitions.items():
        rows = [record for state_id in state_ids for record in groups[state_id]]
        with (args.out / f"{name}.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        summary["partitions"][name] = len(rows)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
