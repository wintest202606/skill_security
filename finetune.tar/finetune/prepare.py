"""Convert labelled PE-analysis JSONL into labelled Kev requests.

    uv run python finetune/prepare.py finetune/pe-spec.json input.jsonl --out records.jsonl
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def get_path(row: dict, path: str):
    value = row
    for part in path.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def state_for(row: dict, fields: list[str]):
    """Keep the tool output intact; PE attributes are the model input."""
    values = {field: get_path(row, field) for field in fields}
    values = {field: value for field, value in values.items() if value is not None}
    if not values:
        return None
    return next(iter(values.values())) if len(values) == 1 else values


def label_for(question: dict, value):
    kind = question["type"]
    if kind == "noul":
        if not isinstance(value, bool):
            raise ValueError("noul label must be true or false")
    elif kind == "choice":
        if value not in question["criteria"]:
            raise ValueError(f"choice label {value!r} is not a criterion")
    elif kind == "score":
        if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < len(question["criteria"]):
            raise ValueError("score label must be a zero-based criterion index")
    else:
        raise ValueError(f"unknown question type {kind!r}")
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", type=Path)
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text(encoding="utf-8"))
    required = {"source", "id_field", "state_fields", "questions"}
    missing = required - set(spec)
    if missing:
        parser.error(f"spec is missing {sorted(missing)}")
    if not isinstance(spec["state_fields"], list) or not spec["state_fields"]:
        parser.error("state_fields must be a non-empty list")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    kept, skipped, labels = 0, Counter(), {qid: Counter() for qid in spec["questions"]}
    with args.input.open(encoding="utf-8") as source, args.out.open("w", encoding="utf-8", newline="\n") as output:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                sample_id = get_path(row, spec["id_field"])
                state = state_for(row, spec["state_fields"])
                if sample_id in (None, "") or state in (None, {}, []):
                    raise ValueError("missing id or state")
                questions = {}
                for qid, question in spec["questions"].items():
                    label = label_for(question, get_path(row, question["label_field"]))
                    questions[qid] = {key: value for key, value in question.items() if key in {"type", "instructions", "criteria"}}
                    questions[qid]["label"] = label
                    labels[qid][str(label).lower() if isinstance(label, bool) else str(label)] += 1
                record = {"state": state, "questions": questions, "_meta": {"id": str(sample_id), "source": spec["source"]}}
                output.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
                kept += 1
            except (TypeError, ValueError, KeyError, json.JSONDecodeError) as error:
                skipped[str(error)] += 1
                print(f"skipped line {line_number}: {error}")
    print(f"wrote {kept} records to {args.out}; skipped {sum(skipped.values())}")
    for qid, counts in labels.items():
        print(f"{qid}: " + ", ".join(f"{label}={count}" for label, count in counts.most_common()))
    if not kept:
        raise SystemExit("no valid records were written")


if __name__ == "__main__":
    main()
