# PE analysis fine-tuning

This directory turns labelled PE-analysis output into Kev training records. It does not upload files or run training by itself.

## Input

`data/pe-analysis.example.jsonl` has one JSON object per file. It follows the structure emitted by a PE inspection tool: `header`, `sections`, `imports`, and `resources` all stay below `analysis`, while the ground-truth malware label stays below `labels`.

```json
{
  "sha256": "stable file identifier",
  "analysis": {
    "header": {"target_machine": "Intel 386", "entry_point": 61982, "contained_sections": 3},
    "sections": [{"name": ".text", "virtual_size": 53796, "raw_size": 54272, "entropy": 5.63, "md5": "...", "chi2": 1287602}],
    "imports": ["mscoree.dll"],
    "resources": {"by_type": {"RT_MANIFEST": 1}, "items": [{"sha256": "...", "file_type": "XML", "entropy": 4.97}]}
  },
  "labels": {"malicious": false}
}
```

`prepare.py` preserves the complete `analysis` object as the Kev state, including the PE properties supplied by the tool. The top-level SHA-256 is retained in `_meta.id` for traceability and split control. Large raw blobs, full disassembly, and byte arrays should stay out of `analysis` unless you have measured that their size fits the selected context limit.

`pe-spec.example.json` defines which fields become the model state and which label field answers each question. Copy both example files before editing them.

## Build the dataset

```powershell
uv run python finetune/prepare.py finetune/pe-spec.example.json finetune/data/pe-analysis.example.jsonl --out finetune/data/records.jsonl
uv run python finetune/split.py finetune/data/records.jsonl --out finetune/data/pe-v1
```

The splitter groups exact same states so a file does not appear in both training and evaluation. It writes `train.jsonl`, `calibration.jsonl`, and `development.jsonl`.

## Train and evaluate

Use CUDA for training. The command starts from Kev-0.8B and writes a new checkpoint below `finetune/runs/`.

```powershell
uv run python finetune/train.py --data finetune/data/pe-v1 --out finetune/runs/pe-v1 --device cuda
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/development.jsonl --out finetune/runs/pe-v1-development --device cuda
uv run python finetune/calibrate.py --run finetune/runs/pe-v1 --rows finetune/runs/pe-v1-development/rows.json
```

Fit the temperature only on calibration data. To do that, first score `calibration.jsonl`, then pass its `rows.json` to `calibrate.py`. Score development data only after calibration.

```powershell
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/calibration.jsonl --out finetune/runs/pe-v1-calibration --device cuda
uv run python finetune/calibrate.py --run finetune/runs/pe-v1 --rows finetune/runs/pe-v1-calibration/rows.json
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/development.jsonl --out finetune/runs/pe-v1-development-calibrated --device cuda
```

Do not tune labels or thresholds against `development.jsonl`. Keep an additional final test file if this will block or quarantine files.

## Label rules

- The provided specification uses the boolean `labels.malicious` field; it must be JSON `true` or `false`.
- Keep the question text identical between training and production.
- Include benign and malicious files from the same sources that production will see. The labels must come from an independent analyst decision, sandbox result, or later disposition.
