# PE analysis fine-tuning

This directory turns labelled PE-analysis output into Kev training records. It does not upload files or run training by itself.

## Input

`data/pe-analysis.example.jsonl` has one JSON object per file. Keep the analysis data under `analysis` and labels under `labels`. Large raw blobs, disassembly, and byte arrays should stay out of `analysis`. Include the features that a production classifier may use, such as imports, sections, signer information, entropy, strings, and rules hit.

`pe-spec.example.json` defines which fields become the model state and which label field answers each question. Copy both example files before editing them.

## Build the dataset

```powershell
uv run python finetune/prepare.py finetune/pe-spec.example.json finetune/data/pe-analysis.example.jsonl --out finetune/data/records.jsonl
uv run python finetune/split.py finetune/data/records.jsonl --out finetune/data/pe-v1
```

The splitter groups exact same states so a file does not appear in both training and evaluation. It writes `train.jsonl`, `calibration.jsonl`, and `development.jsonl`.

## Train and evaluate

Use CUDA for training. The command starts from Kev-0.8B and writes a new checkpoint below `finetune/runs/`.

```powershell
uv run python finetune/train.py --data finetune/data/pe-v1 --out finetune/runs/pe-v1 --device cuda
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/development.jsonl --out finetune/runs/pe-v1-development --device cuda
uv run python finetune/calibrate.py --run finetune/runs/pe-v1 --rows finetune/runs/pe-v1-development/rows.json
```

Fit the temperature only on calibration data. To do that, first score `calibration.jsonl`, then pass its `rows.json` to `calibrate.py`. Score development data only after calibration.

```powershell
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/calibration.jsonl --out finetune/runs/pe-v1-calibration --device cuda
uv run python finetune/calibrate.py --run finetune/runs/pe-v1 --rows finetune/runs/pe-v1-calibration/rows.json
uv run python finetune/evaluate.py --run finetune/runs/pe-v1 --data finetune/data/pe-v1/development.jsonl --out finetune/runs/pe-v1-development-calibrated --device cuda
```

Do not tune labels or thresholds against `development.jsonl`. Keep an additional final test file if this will block or quarantine files.

## Label rules

- `noul` labels are JSON booleans.
- `choice` labels must exactly match a key in `criteria`.
- `score` labels are zero-based integers.
- Keep the question text and choice keys identical between training and production.
- Include benign, suspicious, and malicious files from the same sources that production will see. Do not use a hash, filename, path, or vendor detection name as an input feature.
