"""Fit a checkpoint temperature from a calibration benchmark's rows.json."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from kev.checkpoint import read_meta, write_meta
from kev.metrics import metrics
from kev.suite import read_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--rows", required=True, type=Path, help="rows.json produced from calibration.jsonl")
    args = parser.parse_args()
    rows = [row for row in read_json(args.rows) if row["variant"] == "clean"]
    if not rows:
        parser.error("rows contains no clean calibration rows")
    grid = np.exp(np.linspace(np.log(.25), np.log(4), 121))
    temperature = float(grid[int(np.argmin([metrics(rows, float(value))["nll"] for value in grid]))])
    before, after = metrics(rows), metrics(rows, temperature)
    meta = read_meta(args.run)
    meta.temperature = temperature
    meta.extra["temperature_fit"] = {"rows": str(args.rows), "n": len(rows), "method": "minimum NLL over logarithmic grid [0.25, 4]"}
    write_meta(args.run, meta)
    print(f"temperature={temperature:.3f} nll={before['nll']:.4f}->{after['nll']:.4f} ece={before['ece']:.4f}->{after['ece']:.4f}")


if __name__ == "__main__":
    main()
