"""Score a PE-analysis checkpoint on calibration or development records."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")
    args = parser.parse_args()
    if not (args.run / "head.pt").is_file():
        parser.error(f"missing checkpoint metadata in {args.run}")
    if not args.data.is_file():
        parser.error(f"missing data file {args.data}")
    if args.out.exists():
        parser.error(f"refusing to overwrite {args.out}")
    command = [sys.executable, "-m", "kev.benchmark", "--run", str(args.run), "--data", str(args.data), "--out", str(args.out), "--device", args.device]
    print(" ".join(command))
    subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
