"""Launch a PE-analysis delta fine-tune with the repository trainer."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, type=Path, help="directory containing train.jsonl")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--init-from", default="jaredpalmer/kev-0.8b")
    parser.add_argument("--base", default="Qwen/Qwen3.5-0.8B-Base")
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--accum", type=int, default=8)
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")
    parser.add_argument("--dtype", choices=("fp32", "bf16"), default="bf16")
    args = parser.parse_args()
    train = args.data / "train.jsonl"
    if not train.is_file():
        parser.error(f"missing {train}")
    if args.out.exists():
        parser.error(f"refusing to overwrite {args.out}")
    if args.dtype == "bf16" and args.device != "cuda":
        parser.error("bf16 requires CUDA")
    command = [
        sys.executable, "-m", "kev.train", "--data", str(train), "--out", str(args.out),
        "--init_from", args.init_from, "--base", args.base, "--epochs", str(args.epochs),
        "--lr", str(args.lr), "--batch", str(args.batch), "--accum", str(args.accum),
        "--device", args.device, "--dtype", args.dtype,
    ]
    print(" ".join(command))
    subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
